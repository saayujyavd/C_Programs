#include <stdio.h>

#ifdef getchar
#undef getchar
#endif

main()
{
    int getchar(void);
    int c;

    while((c = getchar()) != EOF)
        putchar(c);

    return(0);
}

getchar(void)
{
    static char buf[BUFSIZ];
    static char* bufp = buf;
    static int charsread = 0, i = 0;

    if(charsread == 0)
    {
        charsread = read(0, buf, sizeof(buf));
        bufp = buf;
    }
    if(i < charsread - 1)
        return(bufp[i++]);
    else
    {
        if(charsread < sizeof(buf))
        {
            charsread = i = 0;
            return('\n');
        }
        else
            return(EOF);
    }
    
}
