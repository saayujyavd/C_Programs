#include <stdio.h>

/*
If this version of getchar() is to be compiled with <stdio.h> included,
it will be necessary to #undef the name getchar in case it is implemented as a macro.
*/
#ifdef getchar
#undef getchar
#endif

main()
{
    int getchar(void);
    int c;

    while((c = getchar()) != EOF)
        putchar(c);

    return(0);
}

/*
version of getchar() that does unbuffered input, 
by reading the std. input one character at a time.
*/
getchar(void)
{
    char c; /* c must be a char because read() needs a character pointer */

    return((read(0, &c, 1) == 1) ? (unsigned char)c : EOF);    /*   casting c to unsigned char
                                                                    eliminates any problem of sign extension.
                                                                */
}
