#include <stdio.h>
#include <fcntl.h>

#define PERMS   0666    /* RW for owner, group, others */

FILE* myfopen(char* name, char* mode)
{
    int fd;
    FILE* fp;

    /* find free slot */
    for(fp = _iob; fp < (_iob + OPEN_MAX); fp++)
        if((fp->flag & (_READ | _WRITE)) == 0)    // found free 
            break;                                // slot
                                                    
    if(fp >= (_iob + OPEN_MAX)) /* no free slots */
        return(NULL);

    switch(*mode)
    {
        case 'r':
            if((fd = open(name, O_RDONLY, 0)) == -1)
                fd = creat(name, PERMS);
            break;

        case 'w':
            fd = open(name, O_WRONLY, PERMS);
            break;

        case '+':
            fd = open(name, O_RDWR, PERMS);
            break;

        case 'a':
            if((fd = open(name, O_WRONLY, 0)) == -1)
                fd = creat(name, PERMS);
            lseek(fd, 0L, 2);
            break;

        default:
            return(NULL);
    }
    if(fd == -1)
        return(NULL);
    else
    {
        fp->fd = fd;
        fp->cnt = 0;
        fp->base = NULL;
        fp->flag = (*mode == 'r') ? _READ : _WRITE;
    }

    return(fp);
}

myfclose(FILE* file)
{
    if(file)
        return(close(*(int*)file));
    else
        return(-1);
}
