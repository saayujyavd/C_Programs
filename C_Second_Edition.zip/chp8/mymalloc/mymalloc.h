#pragma once

void* mymalloc(unsigned);
void myfree(void*);
