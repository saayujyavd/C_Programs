//
// calculator.h
//
//      
//
// The reverse Polish (postfix) calculator <calc.h> header.
// 
// Developed by: Saayujya Vishwakumar Deshpande
//

#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 100		/* max size of expression */
#define NUMBER 1	/* signal that a number was found */
