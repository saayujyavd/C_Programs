#pragma once

#define MAX 100	/* max size of expression */
