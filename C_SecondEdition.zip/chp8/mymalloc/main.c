#include <stdio.h>
#include "mymalloc.h"

#define MAX_NAME	256

main()
{
	char* name;

	name = (char*)mymalloc(sizeof(char) * MAX_NAME);
	if (name == NULL)
	{
		fprintf(stderr, "main.c: error allocating space to name\n");
		exit(1);
	}

	printf("Name: ");
	scanf("%s", name);
	printf("Name: %s\n", name);

	if (name)
		myfree(name);
	return(0);
}
