#include "myfsize.h"

#ifndef DIRSIZ
#define DIRSIZ	14
#endif

/* opendir: open a directory for readdir calls */
DIR* myopendir(char* dirname)
{
	int* fd;
	DIR* dp;
	struct stat stbuf;
	
	fd = (int*)malloc(sizeof(int));
	if (((*fd = open(dirname, O_RDONLY, 0)) == -1) || (fstat(*fd, &stbuf) == -1) || ((stbuf.st_mode & S_IFMT) != S_IFDIR) || ((dp = (DIR*)malloc(sizeof(DIR))) == NULL))
		return(NULL);

	dp->wdirp = (_WDIR*)fd;
	return(dp);
}

/* readdir: read directory entries in sequence */
dirent* myreaddir(DIR* dp)
{
	struct direct dirbuf;	/* local directory structure */
	struct dirent dir;

	while (read(*(int*)dp->wdirp, (char*)&dirbuf, sizeof(dirbuf)) != -1)
	{
		if (dirbuf.d_ino == 0)	/* means slot is not in use */
			continue;
		dir.d_ino = dirbuf.d_ino;
		strncpy(dir.d_name, dirbuf.d_name, DIRSIZ);
		*(dir.d_name + DIRSIZ) = '\0';	/* ensure termination */
		return(&dir);
	}

	return(NULL);
}

/* closedir: close directory opened by opendir */
void myclosedir(DIR* dp)
{
	if (dp)
	{
		close(dp->wdirp);
		free(dp);
	}

}
