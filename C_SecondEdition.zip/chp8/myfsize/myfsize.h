#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>

void mydirwalk(char*, void (*fcn)(char*));
DIR* myopendir(char*);
dirent* myreaddir(DIR*);
void myclosedir(DIR*);
