#include "myfsize.h"

/* apply fsize() to all files in dir */
void mydirwalk(char* dirname, void (*fsize)(char*))
{
	DIR* directory;
	dirent* fname;
	char d_name[MAX_PATH];

	if ((directory = opendir(dirname)) != NULL)
	{
		while ((fname = readdir(directory)) != NULL)
		{
			/* skip the read directory/file if it is self(".") or parent("..") */
			if ((strcmp(fname->d_name, ".") != 0) && (strcmp(d_name, "..") != 0))
			{
				sprintf(d_name, "%s/%s", dirname, fname->d_name);
				(*fsize)(d_name);
			}

		}

	}
	else
	{
		fprintf(stderr, "dirwalk: can't open %s\n", dirname);
		return;
	}

	if (fname)
		fname = NULL;
	if (directory)
		closedir(directory);
}
