#pragma once

#include <stdio.h>
#include <stdlib.h>

#define MAXCHRS	256
