#include <stdio.h>

main()
{
	printf("%d\n", EOF);

}
