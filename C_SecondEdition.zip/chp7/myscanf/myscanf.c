#include <stdarg.h>
#include <stdlib.h>

/* minimal scanf() with variable argument list */
myscanf(char* fmt, ...)
{
    static int remblk(void);
    /* ... */
    va_list ap;
    char* ptr;
    int c, chrs;

    va_start(ap, fmt);
    for(ptr = fmt, chrs = 0; *ptr; ptr++, chrs++)
    {
        if(*ptr == '%')
        {
            switch(*++ptr)
            {
                case 'd':
                case 'i':
                    c = remblk();

                    int *tmp = (int*)va_arg(ap, int*);
                    while(isdigit(c) && (c != ' '))
                    {
                        *tmp = (10 * *tmp) + (c - '0');
                        c = getchar();
                    }
                    tmp = NULL;

                    break;

                default:
                    break;
                    
            }

        }
        else
            getchar();

    }
    va_end(ap);

    return(chrs);
}

static remblk(void)
{
    int c;

    while((c = getchar()) == ' ')
        ;
    return(c);
}
